import comments from './comments';

// XXX: Here, we can automatically generate this file based on the
// actions inside this directory.
const actions = {
  comments
};

export default actions;
