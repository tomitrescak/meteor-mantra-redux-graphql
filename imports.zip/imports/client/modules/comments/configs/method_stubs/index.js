import comments from './comments';

// XXX: Here we can auto generate this file based on the method stubs
export default function (context) {
  comments(context);
}
