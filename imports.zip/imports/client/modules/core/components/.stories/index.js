import '../style.css';
import './post';
import './postlist';
import './newpost';
import './navigation';
import './main_layout';
