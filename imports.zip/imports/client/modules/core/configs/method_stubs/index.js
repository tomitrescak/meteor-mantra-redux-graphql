import posts from './posts';

export default function (context) {
  posts(context);
}
