import posts from './posts';

export default function () {
  posts();
}
